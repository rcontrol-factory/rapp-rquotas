## Packages
jspdf | Generate PDF estimates client-side
jspdf-autotable | Table support for PDF generation

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  mono: ["JetBrains Mono", "monospace"],
}
